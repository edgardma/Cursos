package pe.com.dyd.spring.boot.backend.apirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBackendApirestApplicationTests {

	@Test
	void contextLoads() {
	}

}
